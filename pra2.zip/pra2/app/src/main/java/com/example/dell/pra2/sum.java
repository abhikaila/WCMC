package com.example.dell.pra2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class sum extends AppCompatActivity {

    EditText mNum1, mNum2;
    Button mAdd;
    float num1,num2,sum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sum);

        mNum1 = findViewById(R.id.num1Et);
        mNum2 = findViewById(R.id.num2Et);
        mAdd = findViewById(R.id.addBtn);

        mAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(mNum1.getText().toString()) &&
                        TextUtils.isEmpty(mNum2.getText().toString())){
                    Toast.makeText(sum.this, "Please enter number...", Toast.LENGTH_SHORT).show();
                }else {
                    num1 = Float.parseFloat(mNum1.getText().toString().trim());
                    num2 = Float.parseFloat(mNum2.getText().toString().trim());
                    sum = num1+num2;
                    Toast.makeText(sum.this, "Sum = "+sum, Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
}
